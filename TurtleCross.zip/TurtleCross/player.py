from turtle import Turtle

STARTING_POSITION = (0, -280)
MOVE_DISTANCE = 20

class Player(Turtle):

    def __init__(self):
        super().__init__()
        self.create_turtle()

    def create_turtle(self):
        self.setheading(90)
        self.penup()
        self.shape("turtle")
        self.color("SpringGreen4")
        self.shapesize(1.5)
        self.reset_position()

    def reset_position(self):
        self.goto(STARTING_POSITION)

    def move_forward(self):
        self.forward(MOVE_DISTANCE)

    def move_backward(self):
        self.forward(-MOVE_DISTANCE)
