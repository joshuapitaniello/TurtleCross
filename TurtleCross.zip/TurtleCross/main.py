import time
from turtle import Screen, Turtle
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard


screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)
screen.bgcolor("PeachPuff1")
screen.title("Turtle Cross")

# game variables
player = Player()
level = Scoreboard()
car_manager = CarManager()

water = Turtle()
water.shape("square")
water.color("DeepSkyBlue2")
water.penup()
water.shapesize(stretch_wid=1, stretch_len=32)
water.goto(0,290)

count = 0

screen.listen()
screen.onkeypress(player.move_forward, "w")
screen.onkeypress(player.move_forward, "Up")

screen.onkeypress(player.move_backward, "s")
screen.onkeypress(player.move_backward, "Down")

game_is_on = True
while game_is_on:

    count += 1

    car_manager.move()

    # detect collision with cars
    for car in car_manager.cars:
        if player.distance(car) < 20:
            print("hit")
            game_is_on = False

    # detect if player makes it to the other side
    if player.ycor() > 280:
        level.clear()
        level.score += 1
        level.display_text()
        player.reset_position()
        if car_manager.car_speed < 5:
            car_manager.car_speed += 0.5
        if car_manager.spawn_delay_upper_bound > 50:
            car_manager.spawn_delay_upper_bound -= 50
        if car_manager.spawn_delay_lower_bound > 10:
            car_manager.spawn_delay_lower_bound -= 5

    if count >= car_manager.spawn_delay:
        count = 0
        car_manager.get_delay()
        car_manager.spawn_car()
        car_manager.spawn_car()

    time.sleep(0.01)
    screen.update()

game_over = Turtle()
game_over.hideturtle()
game_over.penup()
game_over.write(f"Game Over", align="center", font=("Arial", 50, "bold"))

screen.exitonclick()