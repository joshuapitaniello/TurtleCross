from turtle import Turtle
import random


class CarManager:

    def __init__(self):
        self.cars = []
        self.COLORS = ["firebrick", "firebrick1", "firebrick2", "firebrick3", "firebrick4", "IndianRed4"]
        self.SPAWN_RANGE_Y = [-230, -150, -70, 10, 90, 170]
        self.SPAWN_RANGE_X = [300, 450, 500]

        self.car_speed = 1
        self.spawn_delay = 1

        self.spawn_delay_lower_bound = 50
        self.spawn_delay_upper_bound = 200

        for i in range(5):
            self.spawn_car()

    def spawn_car(self):
        car = Turtle()
        car.penup()
        car.shape("square")
        car.color(random.choice(self.COLORS))
        car.shapesize(stretch_wid=1.5, stretch_len=2.5)
        car.goto(self.get_random_x(), self.get_random_y())
        self.cars.append(car)

    def get_random_y(self):
        return random.choice(self.SPAWN_RANGE_Y)

    def get_random_x(self):
        return random.choice(self.SPAWN_RANGE_X)

    def get_delay(self):
        self.spawn_delay = random.randint(self.spawn_delay_lower_bound, self.spawn_delay_upper_bound)

    def move(self):
        for car in self.cars:
            if car.xcor() < -330:
                car.hideturtle()
                self.cars.remove(car)
                del car
            else:
                car.forward(-self.car_speed)

